小辫子酱 — Codex / ChatGPT Pets 分享包

这是已完成的宠物原始文件，长发为左一束、右一束，共两束。

给朋友使用
1. 把整个 ZIP 作为文件发送给朋友。对方先解压。
2. 对方在具有 Pets 自定义宠物功能的 Codex / ChatGPT Work 中新建聊天，上传 spritesheet.png。
3. 复制 IMPORT.txt 的全部内容发给助手，请它验证、按 v2 格式创建并启用。

要上传的是 spritesheet.png 原文件。请用“发送文件/原图”，避免聊天软件压缩或转为 JPEG，也不要用截图、preview.gif 或 preview.mp4 代替。

功能要求
对方的客户端和账号需要已开放 Pets，并能导入/创建自定义宠物及读取 v2 精灵图。没有这一功能时，仅下载本包不能让客户端自动获得该功能。每位朋友需要导入到自己的账户。

文件内容
- spritesheet.png：可导入的透明原始精灵图，1536×2288，v2，8列×11行。
- IMPORT.txt：可直接复制的中文导入提示词。
- pet-metadata.json：名称、描述和格式信息，供助手读取；它本身不是一键安装器。
- preview.gif / preview.mp4：16方向转头预览。
- actions.gif：九组标准动作预览。
- four-poses.png：四个转头方向的静态预览。

可选：通过公开图片地址安装
OpenAI 官方文档记录了桌面客户端的宠物安装链接。若你自行将 spritesheet.png 放到公开可访问、无需登录的 HTTPS 原图地址，可使用：
codex://pets/install?name=小辫子酱&imageUrl=原图的HTTPS地址&spriteVersionNumber=2
实际构造链接时，要分别对 name、imageUrl 的值做 URL 编码。imageUrl 必须指向原始精灵图，不能是 ZIP、图片查看页面或临时过期的下载地址。必须保留 spriteVersionNumber=2，因为省略时默认是 v1。

官方参考：https://learn.chatgpt.com/docs/reference/commands#pets
本文的“上传文件并让助手导入”方法以对方已具备 Pets 创建工具为前提；官方安装链接也仅在 Pets 功能已启用时有效。

导入本文件不需要你的原账号、登录信息或原宠物ID。
